public abstract class Monitor {
        protected StudentAdm adm;

        public abstract void update(Student s, double nota, String className);
}
